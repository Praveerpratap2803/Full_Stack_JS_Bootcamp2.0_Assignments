# Replicate the Following Output

`Assests are Provided!`

![Project 6](./Data%20Analytics%20Landing%20page.png)
